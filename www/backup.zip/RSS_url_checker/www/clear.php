<?php
// Připojení k databázi
$db = new PDO('sqlite:../db/db.sqlite');

// Získání seznamu tabulek
$query = $db->query("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%';");
$tables = $query->fetchAll(PDO::FETCH_ASSOC);

// Vymazání všech záznamů ze všech tabulek
foreach ($tables as $table) {
    $stmt = $db->prepare("DELETE FROM " . $table['name']);
    $stmt->execute();
}

echo "Všechny tabulky byly vyprázdněny.";
?>
 
